#!/bin/bash
roslaunch mavros px4.launch 
#vim /opt/ros/indigo/share/mavros/launch/px4.launch





